//class Demo2.java
import java.io.IOException;
public class Demo2
{
	public static void main(String [] args)
	{
		try
		{
			throw new ExceptionA();
		}
		catch(Exception exA)
		{
			System.out.println("ExceptionA subclass caught.");
		}
		try
		{
			throw new ExceptionB();
		}
		catch(Exception exB)
		{
			System.err.println("ExceptionB subclass caught.");
		}
		try
		{
			throw new NullPointerException();
		}
		catch(Exception e1)
		{
			e1.printStackTrace();
			System.err.println("Exception NullPointerException subclass caught.");
		}
		try
		{
			throw new IOException();
		}
		catch(Exception e2)
		{
			e2.printStackTrace();
		}
	}
}
class ExceptionA extends Exception
{
//empty class body
}
class ExceptionB extends ExceptionA
{
//empty class body
}