//class OverWithdrawException.java
public class OverWithdrawException extends InvalidAmountException
{
	OverWithdrawException()
	{
	}
	OverWithdrawException(String mesage)
	{
		super(mesage);
	}
}