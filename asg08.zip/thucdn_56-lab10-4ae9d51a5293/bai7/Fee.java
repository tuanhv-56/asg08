//class Fee.java

public class Fee extends Account
{
	public final double FEE = 5.00;
	
	public Fee()
	{
		super();
	}
	public Fee(double balance) throws InvalidAmountException
	{
		super(balance);
	}
	public void endMonthCharge()
	{
		//withdraw(FEE);
		balance = balance - FEE;
		//transactions--;
	}
}