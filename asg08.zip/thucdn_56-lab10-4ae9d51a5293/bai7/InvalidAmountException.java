//class InvalidAmountException.java
public class InvalidAmountException extends Exception
{
	InvalidAmountException()
	{
	}
	InvalidAmountException(String mesage)
	{
		super(mesage);
	}
}