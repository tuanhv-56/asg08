//class Gambler.java
//import java.lang
public class Gambler extends Account
{
	public final double PAY_OODS = 0.51;
	
	public Gambler()
	{
		super();
	}
	public Gambler(double balance) throws InvalidAmountException
	{
		super(balance);
	}
	public void withdraw(double amt) throws OverWithdrawException
	{
		if(Math.random() < PAY_OODS)
			super.withdraw(amt * 2);
		else
			super.withdraw(0.00);
		if(amt < 0 || amt > balance/2) throw new OverWithdrawException();
	}
	public void endMonthCharge()
	{
		//No setup
	}
}