//class Account.java

public abstract class Account
{
	protected double balance;
	protected int transactions;
	
	public Account()
	{
		balance = 0;
		transactions = 0;
	}
	public Account(double balance) throws InvalidAmountException
	{
		this.balance = balance;
		transactions = 0;
		if(balance < 0) throw new InvalidAmountException();
	}
	public void withdraw(double amt) throws OverWithdrawException
	{
		balance = balance - amt;
		transactions++;
		if(amt < 0 || amt > balance) throw new OverWithdrawException();
	}
	public void deposit(double amt) throws InvalidAmountException
	{
		balance = balance + amt;
		transactions++;
		if(amt < 0) throw new InvalidAmountException();
	}
	public double getBalance()
	{
		return balance;
	}
	public void endMonth()
	{
		endMonthCharge();
		String myClassName = (getClass()).getName();
		System.out.printf("(" + myClassName + ")" + "\t" + "Transactions: " + transactions + "\tBalance: " + balance + "\n");
		transactions = 0;
	}
	protected abstract void endMonthCharge();
}