//class NickleNDime.java

public class NickleNDime extends Account
{
	public final double WITHDRAW_FEE = 0.5;
	int withdrawCount;
	
	public NickleNDime()
	{
		super();
		withdrawCount = 0;
	}
	public NickleNDime(double balance) throws InvalidAmountException
	{
		super(balance);
		withdrawCount = 0;
	}
	public void withdraw(double amount) throws OverWithdrawException
	{
		super.withdraw(amount);
		withdrawCount++;
	}
	public void endMonthCharge()
	{
		//withdraw(WITHDRAW_FEE * withdrawCount);
		balance = balance - WITHDRAW_FEE * withdrawCount;
		//transactions--;
		withdrawCount = 0;
	}
}