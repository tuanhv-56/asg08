public class AccountTest {

    public static void main(String args[]){

        try{
            Fee count = new Fee(500);
            System.out.println("Initial money is $500! Not much.");
            count.deposit(1200);
            System.out.println("Withdraw about $350.");
            count.withdraw(350);
            count.endMonth();
            System.out.print("******************************\n\n");
        }catch(OverWithdrawException o){
            System.err.print(o.getClass().getName());
        }catch(InvalidAmountException i){
            System.err.print(i.getClass().getName());
        }
        try{
            NickleNDime nick = new NickleNDime(800);
            System.out.println("Initial money is $800! Not much.");
            nick.deposit(1360);
            nick.withdraw(250);
            nick.withdraw(500);
            nick.endMonth();
            System.out.print("******************************\n\n");
        }catch(OverWithdrawException o){
            System.err.print(o.getClass().getName());
        }catch(InvalidAmountException i){
            System.err.print(i.getClass().getName());
        }

        try{
            Gambler gamb = new Gambler(1000);
            System.out.println("Initial money is $1000! Not much.");
            gamb.deposit(2000);
            gamb.withdraw(400);
            gamb.withdraw(200);
            gamb.withdraw(200);
            gamb.endMonth();
        }catch(OverWithdrawException o){
            System.err.print(o.getClass().getName());
        }catch(InvalidAmountException i){
            System.err.print(i.getClass().getName());
        }
    }
}
