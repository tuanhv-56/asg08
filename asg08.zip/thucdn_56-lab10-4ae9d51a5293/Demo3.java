//class Demo3.java
import java.io.IOException;
public class Demo3
{
	public static void main(String [] args)
	{
		try
		{
			throw new IOException();
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			System.err.println(" ");
		}
		catch(IOException io)
		{
			System.err.println("IOException");
		}
	}
}