//class SomeException.java
public class SomeException
{
	SomeException() throws Exception
	{
		throw new Exception();
	}
	public static void main(String [] args)
	{
		try
		{
			SomeException some = new SomeException();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.err.println("Cautgh Exception method SomeException");
			System.err.println("Class Exception: " + e.getClass().getName());
		}
	}
}