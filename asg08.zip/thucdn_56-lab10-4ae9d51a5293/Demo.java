//class Demo.java
public class Demo
{
	public static void main(String [] args)
	{
		try
		{
			throw new ExceptionC();
		}
		catch(ExceptionA ex1)
		{
			System.err.println("First Exception C subclass caught.");
		}
		try
		{
			throw new ExceptionB();
		}
		catch(ExceptionA ex2)
		{
			System.err.println("Second Exception B subclass caught.");
		}
	}
}
class ExceptionA extends Exception
{
//empty class body
}
class ExceptionB extends ExceptionA
{
//empty class body
}
class ExceptionC extends ExceptionB
{
//empty class body
}