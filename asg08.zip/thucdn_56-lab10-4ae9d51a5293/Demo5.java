//class Demo5.java
import java.io.IOException;
public class Demo5
{
	Demo5()
	{
	}
	public void someMethod2() throws Exception
	{
		throw new Exception();
		throw new IOException();
	}
	public void someMethod() throws Exception
	{
		try
		{
			someMethod2();
		}
		catch(Exception e)
		{
			throw e;
		}
	}
	public static void main(String [] args)
	{
		Demo5 d = new Demo5();
		
		try
		{
			d.someMethod();
		}
		catch(Exception exp)
		{
			System.err.println("Caught Exception of method someMethod2.");
		}
	}
}