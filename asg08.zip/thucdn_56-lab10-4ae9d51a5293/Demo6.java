//class Demo6.java
import java.util.Scanner;
import java.util.InputMismatchException;
import java.lang.ArithmeticException;
public class Demo6
{
	Demo6()
	{
	}
	public void method1()
	{
		throw new InputMismatchException();
	}
	public void method() throws InputMismatchException,ArithmeticException
	{
		try
		{
			method1();
			throw new ArithmeticException();
		}
		catch(ArithmeticException a)
		{
			throw a;
		}
		catch(InputMismatchException i)
		{
			System.err.println("Input error!");
		}
		
	}
	public static void main(String [] args)
	{
		Demo6 d = new Demo6();
		
		try
		{
			d.method();
		}
		catch(ArithmeticException e2)
		{
			System.err.println("Arithmetic error!");
		}
	}
}